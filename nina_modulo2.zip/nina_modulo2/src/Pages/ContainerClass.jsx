
import FormClass from "../Components/FormClass";


function ContainerClass(){
    
        return(
            <div className=" container text-center">
                <div className=" App-home row">
                 
                    <div className="bg-glass col align-self-center">
                    <FormClass/>
                    </div>
                  
                </div>
              
            </div>
          
        )
    } 
export default ContainerClass